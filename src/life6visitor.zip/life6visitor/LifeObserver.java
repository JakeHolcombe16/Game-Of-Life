package life6visitor;

public interface LifeObserver {
//	public int getRows();
//	public int getCols();
//	public Cell getCell(int row, int col);
	void update();
}
